from flask import Blueprint, render_template, request, redirect, url_for
from .models import Skill
from . import db

bp = Blueprint('main', __name__)

@bp.route('/')
def profile():
    skills = Skill.query.all()
    return render_template('profile.html', skills=skills)

@bp.route('/skills')
def skills():
    skills = Skill.query.all()
    return render_template('skills.html', skills=skills)

@bp.route('/add_skill', methods=['GET', 'POST'])
def add_skill():
    if request.method == 'POST':
        name = request.form['name']
        level = request.form['level']
        new_skill = Skill(name=name, level=level)
        db.session.add(new_skill)
        db.session.commit()
        return redirect(url_for('main.skills'))
    return render_template('add_skill.html')