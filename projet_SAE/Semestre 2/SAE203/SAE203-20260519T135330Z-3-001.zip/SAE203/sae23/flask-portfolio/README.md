# Flask Portfolio

## Description
Un portfolio dynamique développé avec Flask, connecté à une base de données MySQL Dockerisée.

## Installation et lancement

1. Clone ce dépôt :
```
git clone https://github.com/ton-utilisateur/flask-portfolio.git
cd flask-portfolio
```

2. Construis et lance les containers Docker :
```
docker-compose up --build
```

3. Ouvre ton navigateur à l'adresse [http://localhost:5000](http://localhost:5000)

---

## Structure

- `/app` : code source Flask  
- `docker-compose.yml` : orchestration des containers web et base de données  
- `Dockerfile` : image pour le service Flask